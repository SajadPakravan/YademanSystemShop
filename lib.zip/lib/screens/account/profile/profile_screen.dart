import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:yad_sys/view_models/account/account_view_model.dart';
import 'package:yad_sys/view_models/account/profile_view_model.dart';
import 'package:yad_sys/views/account/profile/profile_view.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key, required this.viewModel});

  final AccountViewModel viewModel;

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  @override
  Widget build(BuildContext context) => Consumer<ProfileViewModel>(
    builder: (context, viewModel, child) => ProfileView(viewModel: viewModel, logout: widget.viewModel.logout),
  );
}
