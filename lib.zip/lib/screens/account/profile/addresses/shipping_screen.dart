import 'package:flutter/material.dart';
import 'package:yad_sys/models/address_model.dart';
import 'package:yad_sys/tools/app_colors.dart';
import 'package:yad_sys/tools/app_dimension.dart';
import 'package:yad_sys/view_models/account/profile/addresses_view_model.dart';
import 'package:yad_sys/widgets/buttons/app_button.dart';
import 'package:yad_sys/widgets/forms/app_text_field.dart';
import 'package:yad_sys/widgets/forms/location_combo.dart';
import 'package:yad_sys/widgets/text_views/app_text.dart';

class ShippingScreen extends StatefulWidget {
  const ShippingScreen({super.key, required this.kind, required this.addressType, required this.viewModel});

  final AddressKind kind;
  final AddressFieldsModel addressType;
  final AddressesViewModel viewModel;

  @override
  State<ShippingScreen> createState() => _ShippingScreenState();
}

class _ShippingScreenState extends State<ShippingScreen> {
  late final vm = widget.viewModel;

  @override
  void initState() {
    super.initState();
    vm.createControllers(widget.addressType);
  }

  @override
  void didUpdateWidget(covariant ShippingScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (identical(oldWidget.addressType, widget.addressType)) return;

    final visibleKeys = vm.visibleFields(widget.addressType).map((field) => field.keyName).toSet();
    final removedKeys = vm.controllers.keys.where((key) => !visibleKeys.contains(key)).toList(growable: false);
    for (final key in removedKeys) {
      vm.controllers.remove(key)?.dispose();
    }

    for (final field in widget.viewModel.visibleFields(widget.addressType)) {
      final value = widget.addressType.value(field.keyName);
      final controller = vm.controllers[field.keyName];
      if (controller == null) {
        vm.controllers[field.keyName] = TextEditingController(text: value);
      } else {
        controller.text = value;
      }
    }

    vm.initialValues = <String, String>{for (final entry in vm.controllers.entries) entry.key: entry.value.text.trim()};
    vm.errors.clear();
  }

  @override
  void dispose() {
    for (final controller in vm.controllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final r = context.responsive;
    final visibleFields = widget.viewModel.visibleFields(widget.addressType);

    return ListView(
      padding: EdgeInsets.fromLTRB(r.pageHorizontalPadding, r.space(18), r.pageHorizontalPadding, r.space(30)),
      children: [
        for (var index = 0; index < visibleFields.length; index++) ...[
          if (visibleFields[index].keyName == 'state')
            LocationCombo(
              title: 'استان',
              hint: 'نام استان را جستجو یا انتخاب کنید',
              icon: Icons.map_outlined,
              emptyMessage: 'استانی پیدا نشد.',
              code: vm.controllers['state']!.text,
              list: vm.provinces,
              errorText: vm.errors['state'],
              onChanged: (value) => setState(() {
                final oldValue = vm.controllers['state']!.text;
                vm.controllers['state']!.text = value;

                if (vm.provinces.any((province) => province.code == value) && value != oldValue) {
                  vm.controllers['city']?.clear();
                }
                vm.errors.remove('state');
              }),
            )
          else
            AppTextField(
              controller: vm.controllers[visibleFields[index].keyName]!,
              title: visibleFields[index].label,
              hint: visibleFields[index].label,
              icon: visibleFields[index].icon,
              keyboardType: visibleFields[index].keyboardType,
              textInputAction: index == visibleFields.length - 1 ? TextInputAction.done : TextInputAction.next,
              errorText: vm.errors[visibleFields[index].keyName],
              onChanged: (_) {
                if (vm.errors.remove(visibleFields[index].keyName) != null) setState(() {});
                setState(() {});
              },
              onSubmitted: (_) {
                if (index == visibleFields.length - 1) vm.submit(context, widget.kind);
              },
            ),
          if (index != visibleFields.length - 1) SizedBox(height: r.space(14)),
        ],
        SizedBox(height: r.space(20)),
        if (widget.viewModel.saveErrorMessage.isNotEmpty) ...[
          AppText.bodySmall(widget.viewModel.saveErrorMessage, color: AppColors.error, textAlign: TextAlign.center),
          SizedBox(height: r.space(10)),
        ],
        AppButton(
          label: 'ثبت تغییرات آدرس',
          icon: Icons.save_outlined,
          loading: widget.viewModel.saving(widget.kind),
          enabled: vm.fieldChanged,
          onPressed: () => vm.submit(context, widget.kind),
        ),
      ],
    );
  }
}