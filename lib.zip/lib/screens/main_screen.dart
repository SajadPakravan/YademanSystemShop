import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:yad_sys/screens/account/account_screen.dart';
import 'package:yad_sys/screens/categories/categories_screen.dart';
import 'package:yad_sys/screens/home/home_screen.dart';
import 'package:yad_sys/screens/shop/shop_screen.dart';
import 'package:yad_sys/tools/app_colors.dart';
import 'package:yad_sys/tools/main_navigation_controller.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key, this.pageIndex = 0});

  final int pageIndex;

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  late int pageIndex;
  late final List<Widget?> _pages;

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual, overlays: SystemUiOverlay.values);

    pageIndex = widget.pageIndex.clamp(0, 3);
    _pages = List<Widget?>.filled(4, null);
    _pages[pageIndex] = _createPage(pageIndex);
    MainNavigationController.instance.attach(_openPage);
  }

  Widget _createPage(int index) {
    return switch (index) {
      0 => const HomeScreen(),
      1 => const ShopScreen(),
      2 => const CategoriesScreen(),
      3 => const AccountScreen(),
      _ => const HomeScreen(),
    };
  }

  void _openPage(int index) {
    if (index == pageIndex) return;

    setState(() {
      _pages[index] ??= _createPage(index);
      pageIndex = index;
    });
  }


  @override
  void dispose() {
    MainNavigationController.instance.detach();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final dark = context.isDarkMode;
    final overlay = SystemUiOverlayStyle(
      statusBarColor: AppColors.transparent,
      statusBarIconBrightness: dark ? Brightness.light : Brightness.dark,
      statusBarBrightness: dark ? Brightness.dark : Brightness.light,
      systemStatusBarContrastEnforced: false,
      systemNavigationBarColor: colors.surface,
      systemNavigationBarIconBrightness: dark ? Brightness.light : Brightness.dark,
      systemNavigationBarContrastEnforced: false,
      systemNavigationBarDividerColor: colors.divider,
    );

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: overlay,
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          body: Stack(
            children: <Widget>[
              for (var index = 0; index < _pages.length; index++)
                if (_pages[index] != null)
                  Positioned.fill(
                    child: Offstage(
                      offstage: pageIndex != index,
                      child: TickerMode(enabled: pageIndex == index, child: _pages[index]!),
                    ),
                  ),
            ],
          ),
          bottomNavigationBar: DecoratedBox(
            decoration: BoxDecoration(border: Border(top: BorderSide(color: colors.divider))),
            child: BottomNavigationBar(
              currentIndex: pageIndex,
              onTap: _openPage,
              items: <BottomNavigationBarItem>[
                BottomNavigationBarItem(icon: Icon(pageIndex == 0 ? Icons.home : Icons.home_outlined), label: 'خانه'),
                BottomNavigationBarItem(icon: Icon(pageIndex == 1 ? Icons.store : Icons.store_outlined), label: 'فروشگاه'),
                BottomNavigationBarItem(icon: Icon(pageIndex == 2 ? Icons.category : Icons.category_outlined), label: 'دسته‌بندی‌ها'),
                BottomNavigationBarItem(icon: Icon(pageIndex == 3 ? Icons.person : Icons.person_outlined), label: 'حساب من'),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
