import 'package:flutter/material.dart';
import 'package:persian_number_utility/persian_number_utility.dart';
import 'package:yad_sys/models/customer_model.dart';
import 'package:yad_sys/screens/web_screen.dart';
import 'package:yad_sys/tools/app_cache.dart';
import 'package:yad_sys/tools/app_colors.dart';
import 'package:yad_sys/tools/app_dimension.dart';
import 'package:yad_sys/tools/go_page.dart';
import 'package:yad_sys/view_models/account/profile_view_model.dart';
import 'package:yad_sys/view_models/product/product_view_model.dart';
import 'package:yad_sys/widgets/text_views/text_body_large_view.dart';
import 'package:yad_sys/widgets/text_views/text_body_medium_view.dart';
import 'package:yad_sys/widgets/text_views/text_body_small_view.dart';

class ProfileView extends StatelessWidget {
  const ProfileView({super.key, required this.viewModel, required this.logout});

  final ProfileViewModel viewModel;
  final Function() logout;

  @override
  Widget build(BuildContext context) {
    final r = context.responsive;

    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: EdgeInsets.symmetric(vertical: r.space(18)),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircleAvatar(radius: r.icon(74, min: 62, max: 88), backgroundImage: NetworkImage(viewModel.user.avatar)),
                SizedBox(height: r.space(10)),
                TextBodyLargeView(viewModel.user.name),
                SizedBox(height: r.space(8)),
                TextBodyMediumView(viewModel.user.name),
                SizedBox(height: r.space(18)),
                _option(
                  context,
                  title: 'مشخصات فردی',
                  icon: Icons.person,
                  subtitle: viewModel.userInfoAlert ? const TextBodySmallView('لطفا مشخصات فردی خود را تکمیل کنید', color: AppColors.error) : null,
                  onTap: () async {
                    // await rightToPage(const PersonalInfoScreen(), arguments: customer);
                    if (await AppCache.getBool('profileChanged')) getCustomer();
                  },
                ),
                _option(
                  context,
                  title: 'تغییر رمز عبور',
                  icon: Icons.lock,
                  onTap: () async {
                    // await rightToPage(const ChangePasswordScreen(), arguments: customer);
                    if (await AppCache.getBool('profileChanged')) logout;
                  },
                ),
                _option(
                  context,
                  title: 'آدرس‌',
                  icon: Icons.location_on,
                  subtitle: viewModel.addressAlert ? const TextBodySmallView('لطفا آدرس خود را وارد کنید', color: AppColors.error) : null,
                  onTap: () {},
                ),
                _option(
                  context,
                  title: 'سبد خرید',
                  icon: Icons.shopping_cart,
                  subtitle: viewModel.cartAlert
                      ? Align(
                          alignment: Alignment.centerRight,
                          child: Container(
                            width: r.icon(25),
                            height: r.icon(25),
                            alignment: Alignment.center,
                            margin: EdgeInsets.only(top: r.space(5)),
                            decoration: const BoxDecoration(shape: BoxShape.circle, color: AppColors.primary),
                            child: TextBodyMediumView(cartNumber.toString().toPersianDigit(), color: AppColors.onBrand, fontWeight: FontWeight.bold),
                          ),
                        )
                      : null,
                  onTap: () async {
                    // await rightToPage(const CartScreen());
                    checkCart();
                  },
                ),
                _option(context, title: 'سفارشات', icon: Icons.shopping_bag, onTap: () {}),
                _option(context, title: 'علاقه‌مندی‌ها', icon: Icons.favorite, onTap: () {}),
                _option(
                  context,
                  title: 'تماس با پشتیبانی',
                  icon: Icons.headphones,
                  onTap: () => rightToPage(const WebScreen(title: 'تماس با پشتیبانی', url: 'https://yademansystem.ir/contact')),
                ),
                _option(context, title: 'خروج از حساب', icon: Icons.logout, onTap: logout),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _option(BuildContext context, {required String title, required IconData icon, Widget? subtitle, required void Function() onTap}) {
    final colors = context.appColors;
    final r = context.responsive;

    return Card(
      margin: EdgeInsets.symmetric(horizontal: r.pageHorizontalPadding, vertical: r.space(7)),
      color: colors.surfaceVariant,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(r.radius(12)),
        side: BorderSide(color: colors.border),
      ),
      child: ListTile(
        contentPadding: EdgeInsets.symmetric(horizontal: r.space(14), vertical: r.space(3)),
        title: TextBodyMediumView(title, fontWeight: FontWeight.w600),
        leading: Icon(icon, color: AppColors.primary),
        trailing: Icon(Icons.arrow_forward_ios, size: r.icon(17), color: colors.textMuted),
        subtitle: subtitle,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(r.radius(12))),
        onTap: onTap,
      ),
    );
  }
}
