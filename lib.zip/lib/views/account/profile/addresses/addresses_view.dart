import 'package:flutter/material.dart';
import 'package:yad_sys/models/address_model.dart';
import 'package:yad_sys/screens/account/profile/addresses/billing_screen.dart';
import 'package:yad_sys/screens/account/profile/addresses/shipping_screen.dart';
import 'package:yad_sys/tools/app_colors.dart';
import 'package:yad_sys/tools/app_dimension.dart';
import 'package:yad_sys/view_models/account/profile/addresses_view_model.dart';
import 'package:yad_sys/widgets/buttons/app_button.dart';
import 'package:yad_sys/widgets/error_connection_widget.dart';
import 'package:yad_sys/widgets/forms/app_text_field.dart';
import 'package:yad_sys/widgets/forms/location_combo.dart';
import 'package:yad_sys/widgets/loading.dart';
import 'package:yad_sys/widgets/text_views/app_text.dart';

class AddressesView extends StatelessWidget {
  const AddressesView({super.key, required this.viewModel});

  final AddressesViewModel viewModel;

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final addresses = viewModel.addresses;

    if (viewModel.isLoading && addresses == null) return const Loading();

    if (addresses == null) {
      return ErrorConnectionWidget(
        errorMessage: viewModel.errorMessage.isNotEmpty ? viewModel.errorMessage : 'دریافت آدرس‌ها انجام نشد.',
        onPressed: () => viewModel.load(refresh: true),
      );
    }

    return Directionality(
      textDirection: TextDirection.rtl,
      child: DefaultTabController(
        length: 2,
        child: Scaffold(
          backgroundColor: colors.background,
          appBar: AppBar(
            centerTitle: true,
            title: const AppText.titleMedium('آدرس‌ها', fontWeight: FontWeight.w700),
            bottom: const TabBar(
              tabs: [
                Tab(text: 'صورتحساب'),
                Tab(text: 'ارسال'),
              ],
            ),
          ),
          body: TabBarView(
            children: [
              BillingScreen(key: const ValueKey('billing_address_form'), kind: AddressKind.billing, addressType: addresses.billing, viewModel: viewModel),
              ShippingScreen(key: const ValueKey('shipping_address_form'), kind: AddressKind.shipping, addressType: addresses.shipping, viewModel: viewModel),
            ],
          ),
        ),
      ),
    );
  }
}
