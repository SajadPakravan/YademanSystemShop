import 'package:yad_sys/models/pagination_model.dart';

import 'package:yad_sys/models/review_item_model.dart';

class ReviewItemsResponseModel {
  const ReviewItemsResponseModel({required this.success, required this.count, required this.data, this.pagination = const PaginationModel()});
  final PaginationModel pagination;

  final bool success;
  final int count;
  final List<ReviewItemModel> data;

  factory ReviewItemsResponseModel.fromJson(Map<String, dynamic> json) {
    final rawData = json['data'] is List ? json['data'] as List : const <dynamic>[];

    return ReviewItemsResponseModel(
      pagination: PaginationModel.fromJson(json['pagination'], totalKey: 'total_comments', fallbackCount: _asInt(json['count'])),
      success: json['success'] == true,
      count: _asInt(json['count']),
      data: rawData
          .whereType<Map>()
          .map((item) => ReviewItemModel.fromJson(Map<String, dynamic>.from(item)))
          .toList(growable: false),
    );
  }
}

int _asInt(dynamic value) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  return int.tryParse(value?.toString() ?? '') ?? 0;
}
