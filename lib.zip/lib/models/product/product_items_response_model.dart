import 'package:yad_sys/models/product/product_item_model.dart';
import 'package:yad_sys/models/pagination_model.dart';

class ProductItemsResponseModel {
  const ProductItemsResponseModel({required this.success, required this.count, required this.data, required this.pagination});
  final bool success;
  final int count;
  final List<ProductItemModel> data;
  final PaginationModel pagination;
  factory ProductItemsResponseModel.fromJson(Map<String, dynamic> json) {
    final data = (json['data'] is List ? json['data'] as List : const []).whereType<Map>().map((item) => ProductItemModel.fromJson(Map<String, dynamic>.from(item))).toList();
    final count = int.tryParse(json['count']?.toString() ?? '') ?? data.length;
    return ProductItemsResponseModel(success: json['success'] == true, count: count, data: data, pagination: PaginationModel.fromJson(json['pagination'], totalKey: 'total_favorites', fallbackCount: count));
  }
}
