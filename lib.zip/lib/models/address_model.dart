class AddressesResponseModel {
  const AddressesResponseModel({required this.success, required this.data});

  final bool success;
  final AddressBookModel data;

  factory AddressesResponseModel.fromJson(Map<String, dynamic> json) {
    return AddressesResponseModel(success: json['success'], data: AddressBookModel.fromJson(json['data']));
  }
}

class AddressBookModel {
  const AddressBookModel({required this.billing, required this.shipping, required this.locations});

  final CustomerAddressModel billing;
  final CustomerAddressModel shipping;
  final AddressLocations locations;

  factory AddressBookModel.fromJson(Map<String, dynamic> json) {
    return AddressBookModel(
      billing: CustomerAddressModel.fromJson(json['billing']),
      shipping: CustomerAddressModel.fromJson(json['shipping']),
      locations: AddressLocations.fromJson(json['locations']),
    );
  }

  bool get hasAnyAddress => billing.hasAddress || shipping.hasAddress;

  AddressBookModel copyWith({CustomerAddressModel? billing, CustomerAddressModel? shipping}) {
    return AddressBookModel(billing: billing ?? this.billing, shipping: shipping ?? this.shipping, locations: locations);
  }

  Map<String, dynamic> toJson() => <String, dynamic>{'billing': billing.toJson(), 'shipping': shipping.toJson()};
}

class CustomerAddressModel {
  const CustomerAddressModel({required this.values, required this.availableFields});

  static const List<String> standardFields = <String>[
    'first_name',
    'last_name',
    'company',
    'country',
    'state',
    'city',
    'address_1',
    'address_2',
    'postcode',
    'email',
    'phone',
  ];

  final Map<String, String> values;
  final Set<String> availableFields;

  factory CustomerAddressModel.fromJson(Map<String, dynamic> json) {
    final values = <String, String>{};
    final available = <String>{};

    for (final field in standardFields) {
      if (!json.containsKey(field)) continue;
      available.add(field);
      values[field] = json[field];
    }

    return CustomerAddressModel(values: Map<String, String>.unmodifiable(values), availableFields: Set<String>.unmodifiable(available));
  }

  String value(String key) => values[key] ?? '';

  bool hasField(String key) => availableFields.contains(key);

  bool get hasAddress {
    const locationFields = <String>['address_1', 'address_2', 'city', 'state', 'postcode', 'country'];
    return locationFields.any((field) => value(field).isNotEmpty);
  }

  bool get isEmpty => values.values.every((value) => value.trim().isEmpty);

  Map<String, dynamic> toJson() => <String, dynamic>{for (final field in availableFields) field: value(field)};
}

class AddressLocations {
  AddressLocations({required this.provinces});

  final List<Province> provinces;

  factory AddressLocations.fromJson(Map<String, dynamic> json) {
    return AddressLocations(provinces: List.castFrom(json['provinces']).map((item) => Province.fromJson(item)).toList());
  }
}

class Province {
  Province({required this.code, required this.name});

  final String code;
  final String name;

  factory Province.fromJson(Map<String, dynamic> json) => Province(code: json['code'], name: json['name']);
}
