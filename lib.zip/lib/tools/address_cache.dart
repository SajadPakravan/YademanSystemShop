import 'package:yad_sys/models/address_model.dart';

class AddressCache {
  AddressCache._();

  static final AddressCache instance = AddressCache._();

  late Set<AddressBookModel> address = <AddressBookModel>{};

  Set<AddressBookModel> get() => address;

  void save(AddressBookModel address) => this.address = address as Set<AddressBookModel>;
}
