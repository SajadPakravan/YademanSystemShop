import 'package:yad_sys/models/auth/auth_model.dart';
import 'package:yad_sys/models/customer_model.dart';
import 'package:yad_sys/tools/app_cache.dart';
import 'package:yad_sys/models/address_model.dart';
import 'package:yad_sys/models/cart_model.dart';
import 'package:yad_sys/models/order/order_model.dart';
import 'package:yad_sys/models/product/product_item_model.dart';
import 'package:yad_sys/models/review_item_model.dart';

class AccountCache {
  AccountCache._();

  static Future<CustomerModel> getCustomer() async {
    return CustomerModel(
      id: await AppCache.getInt('id'),
      username: await AppCache.getString('username'),
      firstName: await AppCache.getString('first_name'),
      lastName: await AppCache.getString('last_name'),
      displayName: await AppCache.getString('display_name'),
      email: await AppCache.getString('email'),
      phone: await AppCache.getString('phone'),
      avatar: await AppCache.getString('avatar'),
      addressCount: await AppCache.getInt('address_count'),
      ordersCount: await AppCache.getInt('orders_count'),
      cartCount: await AppCache.getInt('cart_count'),
      commentsCount: await AppCache.getInt('comments_count'),
    );
  }

  static Future<void> save({AuthModel? auth, CustomerModel? customer}) async {
    final u = auth != null ? auth.user : customer;
    if (u == null) return;
    if (auth != null) await AppCache.setString('token', auth.token);
    await AppCache.setInt('id', u.id);
    await AppCache.setString('username', u.username);
    await AppCache.setString('first_name', u.firstName);
    await AppCache.setString('last_name', u.lastName);
    await AppCache.setString('display_name', u.displayName);
    await AppCache.setString('email', u.email);
    await AppCache.setString('phone', u.phone);
    await AppCache.setString('avatar', u.avatar);
    await AppCache.setInt('address_count', u.addressCount);
    await AppCache.setInt('orders_count', u.ordersCount);
    await AppCache.setInt('cart_count', u.cartCount);
    await AppCache.setInt('comments_count', u.commentsCount);
  }

  static Future<void> clear() async {
    const keys = <String>[
      'token',
      'id',
      'username',
      'first_name',
      'last_name',
      'display_name',
      'email',
      'phone',
      'avatar',
      'date_created',
      'address_count',
      'orders_count',
      'cart_count',
      'comments_count',
    ];
    for (final key in keys) {
      await AppCache.remove(key);
    }
  }
}
