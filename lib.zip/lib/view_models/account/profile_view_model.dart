import 'package:flutter/material.dart';
import 'package:yad_sys/tools/app_cache.dart';

class ProfileViewModel extends ChangeNotifier {
  Future<void> initialize() async {
    
  }
}
