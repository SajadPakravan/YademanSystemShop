import 'package:flutter/material.dart';
import 'package:yad_sys/connections/http_request.dart';
import 'package:yad_sys/models/address_model.dart';
import 'package:yad_sys/tools/app_cache.dart';
import 'package:yad_sys/tools/app_log.dart';
import 'package:yad_sys/tools/sessions/address_session.dart';

enum AddressKind { billing, shipping }

extension AddressKindX on AddressKind {
  String get apiKey => this == AddressKind.billing ? 'billing' : 'shipping';

  String get title => this == AddressKind.billing ? 'صورتحساب' : 'ارسال';
}

class AddressesViewModel extends ChangeNotifier {
  AddressesViewModel({required this.token, AddressModel? initialAddresses, HttpRequest? httpRequest})
    : addresses = AddressSession.get() ?? initialAddresses,
      httpRequest = httpRequest ?? HttpRequest();

  final HttpRequest httpRequest;
  final String token;
  AddressModel? addresses;
  late Map<String, String> initialValues;
  final Map<String, String> errors = <String, String>{};
  bool isLoading = false, isRefreshing = false;
  bool savingBilling = false, savingShipping = false;
  String errorMessage = '', saveErrorMessage = '';
  bool _disposed = false;

  List<LocationOptions> get provinces => addresses?.locations.provinces ?? const <LocationOptions>[];

  bool saving(AddressKind kind) => kind == AddressKind.billing ? savingBilling : savingShipping;

  Future<void> load({bool refresh = false}) async {
    if (AddressSession.get() != null || isLoading || isRefreshing) return;
    isLoading = addresses == null;
    isRefreshing = !isLoading;
    errorMessage = '';
    notifyListeners();

    try {
      final response = await httpRequest.getAddresses(token: token);

      if (_disposed) return;
      if (response is! Map || response['success'] != true) {
        errorMessage = response is Map ? response['message']?.toString() ?? 'دریافت آدرس‌ها انجام نشد.' : 'دریافت آدرس‌ها انجام نشد.';
        return;
      }

      addresses = AddressesResponseModel.fromJson(Map<String, dynamic>.from(response)).data;
      AddressSession.save(addresses!);
    } catch (e) {
      AppLog.error('ADDRESSES LOAD ERROR >>> $e');
      errorMessage = 'دریافت آدرس‌ها انجام نشد. اتصال اینترنت را بررسی کنید.';
    } finally {
      isLoading = isRefreshing = false;
      notifyListeners();
    }
  }

  Future<bool> updateAddress(AddressKind kind, Map<String, String> changes) async {
    if (changes.isEmpty || saving(kind) || addresses == null) return false;
    saveErrorMessage = '';
    _setSaving(kind, true);

    try {
      final response = await httpRequest.updateAddresses(token: token, changes: <String, dynamic>{kind.apiKey: changes});

      if (_disposed) return false;
      if (response is! Map || response['success'] != true) {
        saveErrorMessage = response is Map && response['message'] != null ? response['message'].toString() : 'ذخیره آدرس انجام نشد.';
        return false;
      }

      addresses = AddressesResponseModel.fromJson(Map<String, dynamic>.from(response)).data;
      AddressSession.save(addresses!);
      await AppCache.setInt('address_count', savingBilling && savingShipping ? 2 : 1);

      return true;
    } catch (e) {
      AppLog.error('ADDRESS UPDATE ERROR >>> $e');
      saveErrorMessage = 'ذخیره آدرس انجام نشد. اتصال اینترنت را بررسی کنید.';
      return false;
    } finally {
      _setSaving(kind, false);
    }
  }

  /// بروزرسانی نشانگر ذخیره آدرس و اطلاع به رابط کاربری.
  void _setSaving(AddressKind kind, bool value) {
    if (kind == AddressKind.billing) {
      savingBilling = value;
    } else {
      savingShipping = value;
    }
    notifyListeners();
  }

  final List<FieldMeta> _fieldDefinitions = <FieldMeta>[
    FieldMeta(keyName: 'first_name', label: 'نام', icon: Icons.person_outline_rounded),
    FieldMeta(keyName: 'last_name', label: 'نام خانوادگی', icon: Icons.badge_outlined),
    FieldMeta(keyName: 'company', label: 'شرکت', icon: Icons.business_outlined),
    FieldMeta(keyName: 'country', label: 'کشور', icon: Icons.public_rounded),
    FieldMeta(keyName: 'state', label: 'استان', icon: Icons.map_outlined),
    FieldMeta(keyName: 'city', label: 'شهر', icon: Icons.location_city_outlined),
    FieldMeta(keyName: 'address_1', label: 'آدرس اصلی', icon: Icons.location_on_outlined),
    FieldMeta(keyName: 'address_2', label: 'ادامه آدرس', icon: Icons.add_location_alt_outlined),
    FieldMeta(keyName: 'postcode', label: 'کدپستی', icon: Icons.markunread_mailbox_outlined, keyboardType: TextInputType.number),
    FieldMeta(keyName: 'phone', label: 'شماره همراه', icon: Icons.phone_outlined, keyboardType: TextInputType.phone),
    FieldMeta(keyName: 'email', label: 'ایمیل', icon: Icons.email_outlined, keyboardType: TextInputType.emailAddress),
  ];

  List<FieldMeta> visibleFields(AddressFieldsModel addressType) {
    return _fieldDefinitions.where((field) => addressType.hasField(field.keyName)).toList(growable: false);
  }

  @override
  void notifyListeners() {
    if (!_disposed) super.notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }
}

class FieldMeta {
  const FieldMeta({required this.keyName, required this.label, required this.icon, this.keyboardType = TextInputType.text});

  final String keyName;
  final String label;
  final IconData icon;
  final TextInputType keyboardType;
}
