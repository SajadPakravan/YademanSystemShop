import 'package:flutter/foundation.dart';
import 'package:yad_sys/connections/http_request.dart';
import 'package:yad_sys/models/pagination_model.dart';

class AccountListLoadResult<T> {
  const AccountListLoadResult({required this.success, required this.count, required this.items});
  final bool success;
  final int count;
  final List<T> items;
}

abstract class AccountListViewModel<T> extends ChangeNotifier {
  AccountListViewModel({required this.token, HttpRequest? httpRequest}) : httpRequest = httpRequest ?? HttpRequest();
  final String token;
  final HttpRequest httpRequest;
  List<T> items = <T>[];
  int count = 0;
  int perPage = 20;
  PaginationModel pagination = const PaginationModel();
  bool isLoading = false, isRefreshing = false, isLoadingMore = false;
  bool _disposed = false;
  String errorMessage = '';
  String get loadErrorMessage;
  bool get loadAllPages => false;
  Future<dynamic> request({int page = 1});
  AccountListLoadResult<T> parse(Map<String, dynamic> json);
  bool restoreSessionCache() => false;
  void writeSessionCache() {}

  Future<void> load({bool refresh = false}) async {
    if (isLoading || isRefreshing || isLoadingMore || _disposed) return;
    isLoading = items.isEmpty;
    isRefreshing = !isLoading;
    errorMessage = '';
    notifyListeners();
    try {
      final loaded = <T>[];
      var page = 1;
      late PaginationModel next;
      do {
        final response = await request(page: page);
        if (_disposed) return;
        final map = _checked(response);
        final result = parse(map);
        if (!result.success) throw StateError(loadErrorMessage);
        loaded.addAll(result.items);
        next = PaginationModel.fromJson(map['pagination'], fallbackCount: result.count);
        if (next.currentPage != page || (next.hasNext && result.items.isEmpty)) {
          throw StateError('پاسخ صفحه‌بندی سرور معتبر نیست.');
        }
        page = next.currentPage + 1;
      } while (loadAllPages && next.hasNext);
      items = loaded;
      pagination = next;
      count = next.totalItems;
      if (!next.hasNext) writeSessionCache();
    } catch (e) {
      errorMessage = e is StateError ? e.message.toString() : loadErrorMessage;
    } finally {
      isLoading = isRefreshing = false;
      notifyListeners();
    }
  }

  Future<void> loadMore() async {
    if (_disposed || isLoading || isRefreshing || isLoadingMore || !pagination.hasNext) return;
    isLoadingMore = true;
    errorMessage = '';
    notifyListeners();
    try {
      final page = pagination.currentPage + 1;
      final response = await request(page: page);
      if (_disposed) return;
      final map = _checked(response);
      final result = parse(map);
      final next = PaginationModel.fromJson(map['pagination'], fallbackCount: result.count);
      if (!result.success || next.currentPage != page || (next.hasNext && result.items.isEmpty)) throw StateError(loadErrorMessage);
      items.addAll(result.items);
      pagination = next;
      count = next.totalItems;
      if (!next.hasNext) writeSessionCache();
    } catch (e) {
      errorMessage = e is StateError ? e.message.toString() : loadErrorMessage;
    } finally {
      isLoadingMore = false;
      notifyListeners();
    }
  }

  Map<String, dynamic> _checked(dynamic response) {
    if (response is! Map) throw StateError(loadErrorMessage);
    if (response['success'] != true) throw StateError(response['message']?.toString() ?? loadErrorMessage);
    return Map<String, dynamic>.from(response);
  }
  Future<void> refresh() => load(refresh: true);
  @override
  void notifyListeners() { if (!_disposed) super.notifyListeners(); }
  @override
  void dispose() { _disposed = true; super.dispose(); }
}
