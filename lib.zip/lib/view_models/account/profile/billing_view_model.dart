import 'package:flutter/material.dart';
import 'package:yad_sys/models/address_model.dart';
import 'package:yad_sys/view_models/account/profile/addresses_view_model.dart';
import 'package:yad_sys/widgets/snack_bar_view.dart';

class BillingViewModel extends ChangeNotifier {
  BillingViewModel({
    required this.visibleFields,
    required this.initialValues,
    required this.provinces,
    required this.updateAddress,
    required this.savingBilling,
    required this.errorMessage,
    required this.saveErrorMessage,
    required this.addresses,
  });

  final AddressModel? addresses;
  late final Map<String, TextEditingController> controllers;
  final List<LocationOptions> provinces;
  final List<FieldMeta> visibleFields;
  late final Map<String, String> initialValues;
  final Map<String, String> errors = <String, String>{};
  final Future<bool> updateAddress;
  final bool savingBilling;
  final String errorMessage, saveErrorMessage;

  void createBillingControllers(AddressFieldsModel addressType) {
    controllers = <String, TextEditingController>{
      for (final field in visibleFields) field.keyName: TextEditingController(text: addressType.value(field.keyName)),
    };
    initialValues = <String, String>{for (final entry in controllers.entries) entry.key: entry.value.text.trim()};
  }

  bool get fieldChanged {
    for (final entry in controllers.entries) {
      if (entry.value.text.trim() != (initialValues[entry.key] ?? '')) return true;
    }
    return false;
  }

  Map<String, String> get _changes {
    final result = <String, String>{};
    for (final entry in controllers.entries) {
      final value = entry.value.text.trim();
      if (value != (initialValues[entry.key] ?? '')) result[entry.key] = value;
    }
    return result;
  }

  bool _validate() {
    errors.clear();

    final email = controllers['email']?.text.trim() ?? '';
    if (email.isNotEmpty) {
      final emailRegex = RegExp(r"^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+$");
      if (!emailRegex.hasMatch(email)) errors['email'] = 'ایمیل وارد شده معتبر نیست.';
    }

    final phone = (controllers['phone']?.text ?? '').replaceAll(RegExp(r'[\s-]'), '');
    if (phone.isNotEmpty) {
      final iranPhone = RegExp(r'^(?:0\d{10}|\+98\d{10}|98\d{10})$');
      if (!iranPhone.hasMatch(phone)) errors['phone'] = 'شماره تماس وارد شده معتبر نیست.';
    }

    // اگر فهرست استان فعال است، تغییر دستی باید به انتخاب کد معتبر منتهی شود.
    final state = controllers['state']?.text.trim() ?? '';
    if (state != initialValues['state'] && state.isNotEmpty && !provinces.any((province) => province.code == state)) {
      errors['state'] = 'لطفاً استان را از فهرست انتخاب کنید.';
    }

    notifyListeners();
    return errors.isEmpty;
  }

  AddressFieldsModel? address(AddressKind kind) {
    final model = addresses;
    if (model == null) return null;
    return kind == AddressKind.billing ? model.billing : model.shipping;
  }

  Future<void> submit(BuildContext context, AddressKind kind) async {
    FocusManager.instance.primaryFocus?.unfocus();
    if (!fieldChanged || !_validate()) return;

    final success = await updateAddress;

    if (!success) {
      if (context.mounted) SnackBarView.show(context, saveErrorMessage.isNotEmpty ? saveErrorMessage : 'ذخیره آدرس انجام نشد.');
      return;
    }

    final updated = address(kind);
    if (updated != null) {
      for (final entry in controllers.entries) {
        entry.value.text = updated.value(entry.key);
      }
    }

    initialValues = <String, String>{for (final entry in controllers.entries) entry.key: entry.value.text.trim()};
    errors.clear();
    notifyListeners();
    if (context.mounted) SnackBarView.show(context, 'آدرس با موفقیت ذخیره شد.');
  }
}
