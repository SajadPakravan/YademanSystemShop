import 'package:yad_sys/models/order/order_model.dart';
import 'package:yad_sys/view_models/account/profile/account_list_view_model.dart';
import 'package:yad_sys/tools/account_cache.dart';

class OrdersViewModel extends AccountListViewModel<OrderModel> {
  OrdersViewModel({required super.token, super.httpRequest});

  @override
  String get loadErrorMessage => 'دریافت سفارشات انجام نشد.';

  @override
  Future<dynamic> request({int page = 1}) => httpRequest.getOrders(token: token, page: page, perPage: perPage);

  @override
  bool get loadAllPages => true;

  @override
  AccountListLoadResult<OrderModel> parse(Map<String, dynamic> json) {
    final model = OrdersResponseModel.fromJson(json);
    return AccountListLoadResult(success: model.success, count: model.count, items: model.data);
  }

  @override
  bool restoreSessionCache() {
    final cached = AccountCache.orders;
    if (cached == null) return false;
    items = List<OrderModel>.from(cached);
    count = AccountCache.ordersCount;
    return true;
  }

  @override
  void writeSessionCache() {
    AccountCache.orders = List<OrderModel>.unmodifiable(items);
    AccountCache.ordersCount = count;
  }
}
