import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:yad_sys/connections/http_request.dart';
import 'package:yad_sys/models/customer_model.dart';
import 'package:yad_sys/tools/account_cache.dart';
import 'package:yad_sys/tools/app_log.dart';
import 'package:yad_sys/tools/sessions/personal_info_session.dart';
import 'package:yad_sys/widgets/crop_image_view.dart';

class PersonalInfoViewModel extends ChangeNotifier {
  PersonalInfoViewModel({required CustomerModel customer, required this.token, HttpRequest? httpRequest, ImagePicker? imagePicker})
    : _customer = PersonalInfoSession.get() ?? customer,
      httpRequest = httpRequest ?? HttpRequest(),
      imagePicker = imagePicker ?? ImagePicker(),
      usernameController = TextEditingController(text: (PersonalInfoSession.get() ?? customer).username),
      firstNameController = TextEditingController(text: (PersonalInfoSession.get() ?? customer).firstName),
      lastNameController = TextEditingController(text: (PersonalInfoSession.get() ?? customer).lastName),
      phoneController = TextEditingController(text: (PersonalInfoSession.get() ?? customer).phone),
      emailController = TextEditingController(text: (PersonalInfoSession.get() ?? customer).email);

  CustomerModel _customer;
  CustomerModel? updatedCustomer;
  final String token;
  final HttpRequest httpRequest;
  final ImagePicker imagePicker;
  final TextEditingController usernameController, firstNameController, lastNameController, phoneController, emailController;
  String? usernameError, firstNameError, lastNameError, phoneError, emailError, avatarFilePath;
  bool saving = false, pickingAvatar = false, isLoading = false;
  String errorMessage = '';
  bool _disposed = false;

  CustomerModel get customer => _customer;

  Future<void> initialize() async {
    if (PersonalInfoSession.get() != null || isLoading) return;
    isLoading = true;
    errorMessage = '';
    notifyListeners();

    try {
      final response = await httpRequest.getCustomer(token: token);

      if (_disposed) return;
      if (response is! Map || response['success'] != true) throw StateError('دریافت مشخصات فردی انجام نشد.');

      final result = CustomerResponseModel.fromJson(Map<String, dynamic>.from(response));

      _customer = result.data;
      PersonalInfoSession.save(_customer);
      _syncFields();
    } catch (e) {
      errorMessage = 'دریافت مشخصات فردی انجام نشد. برای تلاش مجدد صفحه را باز کنید.';
      if (kDebugMode) print('PERSONAL INFO LOAD ERROR >>> $e');
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  void _syncFields() {
    usernameController.text = _customer.username;
    firstNameController.text = _customer.firstName;
    lastNameController.text = _customer.lastName;
    phoneController.text = _customer.phone;
    emailController.text = _customer.email;
  }

  bool get hasAvatarChange => avatarFilePath != null && avatarFilePath!.isNotEmpty;

  bool get formChanged =>
      usernameController.text.trim() != _customer.username ||
      firstNameController.text.trim() != _customer.firstName ||
      lastNameController.text.trim() != _customer.lastName ||
      phoneController.text.trim() != _customer.phone ||
      emailController.text.trim() != _customer.email ||
      hasAvatarChange;

  void fieldChanged() {
    if (errorMessage.isNotEmpty) errorMessage = '';
    notifyListeners();
  }

  bool validate() {
    final username = usernameController.text.trim(), firstName = firstNameController.text.trim();
    final lastName = lastNameController.text.trim(), phone = phoneController.text.trim(), email = emailController.text.trim();
    usernameError = username.length < 4 ? 'نام کاربری باید حداقل ۴ کاراکتر باشد.' : null;
    firstNameError = firstName.isEmpty ? 'نام را وارد کنید.' : null;
    lastNameError = lastName.isEmpty ? 'نام خانوادگی را وارد کنید.' : null;
    phoneError = phone.isEmpty
        ? 'شماره همراه را وارد کنید.'
        : !RegExp(r'^(?:\+98|0098|98|0)?9\d{9}$').hasMatch(phone)
        ? 'شماره همراه معتبر نیست.'
        : null;
    emailError = email.isNotEmpty && !RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$').hasMatch(email) ? 'ایمیل معتبر نیست.' : null;
    notifyListeners();
    return usernameError == null && firstNameError == null && lastNameError == null && phoneError == null && emailError == null;
  }

  Future<void> pickAvatar(BuildContext context, ImageSource source) async {
    if (pickingAvatar || saving || isLoading) return;
    pickingAvatar = true;
    errorMessage = '';
    notifyListeners();
    try {
      final picked = await imagePicker.pickImage(source: source, imageQuality: 95, maxWidth: 2400, maxHeight: 2400);
      if (picked == null || !context.mounted) return;
      final cropped = await cropImageView(context: context, imageFile: picked.path);
      if (cropped != null) avatarFilePath = cropped.path;
    } catch (e) {
      if (kDebugMode) print('AVATAR PICK ERROR >>> $e');
      errorMessage = 'انتخاب یا برش تصویر انجام نشد.';
    } finally {
      pickingAvatar = false;
      notifyListeners();
    }
  }

  Future<bool> submit() async {
    if (saving || isLoading || PersonalInfoSession.get() == null || !formChanged || !validate()) return false;
    saving = true;
    errorMessage = '';
    notifyListeners();

    try {
      final changes = <String, dynamic>{};

      void addChanged(String key, String value, String original) {
        if (value != original) changes[key] = value;
      }

      addChanged('username', usernameController.text.trim(), _customer.username);
      addChanged('first_name', firstNameController.text.trim(), _customer.firstName);
      addChanged('last_name', lastNameController.text.trim(), _customer.lastName);
      addChanged('email', emailController.text.trim(), _customer.email);
      addChanged('phone', phoneController.text.trim(), _customer.phone);

      if (hasAvatarChange) {
        final bytes = await File(avatarFilePath!).readAsBytes();
        changes['avatar'] = 'data:image/jpeg;base64,${base64Encode(bytes)}';
      }

      if (changes.isEmpty) return false;

      final response = await httpRequest.updateCustomer(token: token, changes: changes);

      if (response is! Map || response['success'] != true) {
        errorMessage = response is Map && response['message']?.toString().isNotEmpty == true ? response['message'].toString() : 'ویرایش مشخصات فردی انجام نشد.';
        return false;
      }

      final json = CustomerResponseModel.fromJson(Map<String, dynamic>.from(response));

      _customer = json.data;
      updatedCustomer = json.data;
      avatarFilePath = null;
      _syncFields();
      PersonalInfoSession.save(_customer);
      await AccountCache.save(customer: _customer);
      return true;
    } catch (e) {
      AppLog.error('CUSTOMER UPDATE ERROR >>> $e');
      errorMessage = 'ویرایش مشخصات فردی انجام نشد. اتصال اینترنت را بررسی کنید.';
      return false;
    } finally {
      saving = false;
      notifyListeners();
    }
  }

  /// جلوگیری از بازسازی صفحه پس از dispose.
  @override
  void notifyListeners() {
    if (!_disposed) super.notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    usernameController.dispose();
    firstNameController.dispose();
    lastNameController.dispose();
    phoneController.dispose();
    emailController.dispose();
    super.dispose();
  }
}
