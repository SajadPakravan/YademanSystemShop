import 'package:yad_sys/models/review_item_model.dart';
import 'package:yad_sys/models/review_items_response_model.dart';
import 'package:yad_sys/view_models/account/profile/account_list_view_model.dart';
import 'package:yad_sys/tools/account_cache.dart';

class ReviewsViewModel extends AccountListViewModel<ReviewItemModel> {
  ReviewsViewModel({required super.token, super.httpRequest});

  @override
  String get loadErrorMessage => 'دریافت نظرات شما انجام نشد.';

  @override
  Future<dynamic> request({int page = 1}) => httpRequest.getCustomerComments(token: token, page: page, perPage: perPage);

  @override
  AccountListLoadResult<ReviewItemModel> parse(Map<String, dynamic> json) {
    final model = ReviewItemsResponseModel.fromJson(json);
    return AccountListLoadResult(success: model.success, count: model.count, items: model.data);
  }

  @override
  bool restoreSessionCache() {
    final cached = AccountCache.reviews;
    if (cached == null) return false;
    items = List<ReviewItemModel>.from(cached);
    count = AccountCache.reviewsCount;
    return true;
  }

  @override
  void writeSessionCache() {
    AccountCache.reviews = List<ReviewItemModel>.unmodifiable(items);
    AccountCache.reviewsCount = count;
  }
}
